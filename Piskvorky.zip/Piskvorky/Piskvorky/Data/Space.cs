﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Piskvorky.Data
{
    public class Space
    {
        public Space()
        {
            Value = "-";
        }

        public string Value { get; set; }
    }
}
